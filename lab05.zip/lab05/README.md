You can find the specification for this lab here:

https://unswcse.atlassian.net/wiki/spaces/cs2511/pages/29261825/Lab+05
