package unsw.sso;

import java.util.HashMap;
import java.util.Map;

import unsw.sso.providers.Hoogle;
import unsw.sso.providers.LinkedOut;

public class Browser {
    private Token currentToken = null;
    private String currentPage = null;
    private String previousPage = null;
    private ClientApp currentApp = null;

    private Map<ClientApp, Token> cache = new HashMap<ClientApp, Token>();

    public void visit(ClientApp app) {
        currentToken = cache.get(app);
        
        this.previousPage = null;
        if (currentToken != null) {
            this.currentPage = "Home";
        } else {
            this.currentPage = "Select a Provider";
        }
        this.currentApp = app;
    }

    public String getCurrentPageName() {
        return this.currentPage;
    }

    public void clearCache() {
        cache.remove(currentApp);
    }

    public void interact(Object using) {
        if (using == null) {
            this.currentPage = this.previousPage;
            if (this.currentPage == null) {
                this.visit(this.currentApp);
            }
            return;
        }

        switch (currentPage) {
            case "Select a Provider": {
                // if the currentApp doesn't have hoogle
                // then it has no providers, which just will prevent
                // transition.
                if (using instanceof Hoogle && currentApp.hasProvider(Hoogle.class)) {
                    this.previousPage = currentPage;
                    this.currentPage = "Hoogle Login";
                } else if (using instanceof LinkedOut && currentApp.hasProvider(LinkedOut.class)) {
                    this.previousPage = currentPage;
                    this.currentPage = "LinkedOut Login";
                    // do nothing...
                }
                break;
            }
            case "Hoogle Login": {
                if (using instanceof Token) {
                    Token token = (Token) using;
                    if (token.getAccessToken() != null) {
                        this.previousPage = currentPage;
                        this.currentPage = "Home";
    
                        this.currentToken = token;
                        this.currentApp.registerUser((Token)token);
                        cache.put(currentApp, token);
                    } else {
                        // If accessToken is null, then the user is not authenticated
                        // Go back to select providers page
                        this.currentPage = "Select a Provider";
                    }
                } else {
                    // do nothing...
                }

                break;
            }
            case "LinkedOut Login": {
                if (using instanceof Token) {
                    Token token = (Token) using;
                    if (token.getAccessToken() != null) {
                        this.previousPage = currentPage;
                        this.currentPage = "Home";
    
                        this.currentToken = token;
                        this.currentApp.registerUser((Token)token);
                    } else {
                        // If accessToken is null, then the user is not authenticated
                        // Go back to select providers page
                        this.currentPage = "Select a Provider";
                    }
                } else {
                    // do nothing...
                }

                break;
            }
            case "Home": {
                // no need to do anything
                break;
            }
        }
    }
}
