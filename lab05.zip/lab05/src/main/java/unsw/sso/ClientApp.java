package unsw.sso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import unsw.sso.providers.Provider;

public class ClientApp {
    private List<Provider> providersList = new ArrayList<Provider>();
    private Map<String, Boolean> usersExist = new HashMap<>();
    private final String name;

    public ClientApp(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void registerUser(Token token) {
        usersExist.put(token.getUserEmail(), true);
    }

    public void registerProvider(Provider p) {
        providersList.add(p);
    }

    public boolean hasProvider(Class<? extends Provider> provider) {
        return providersList.stream().anyMatch(x -> provider.equals(x.getClass()));
    }

    public boolean hasUserForProvider(String email, Provider provider) {
        return hasProvider(provider.getClass()) && this.usersExist.getOrDefault(email, false);
    }
}
