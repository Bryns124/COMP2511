package unsw.sso.pages;

public class HomePage extends Page {
    @Override
    public Page interact(Object o) {
        return this;
    }

    @Override
    public String getPageName() {
        return "Home";
    }
}
