package unsw.sso.pages;

public class HoogleLoginPage extends Page {
    
}
