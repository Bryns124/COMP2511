package unsw.sso.pages;

public class InstahamPage extends Page {
    
}
