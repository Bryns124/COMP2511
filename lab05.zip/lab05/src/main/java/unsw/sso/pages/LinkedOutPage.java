package unsw.sso.pages;

public class LinkedOutPage extends Page {
    
}
