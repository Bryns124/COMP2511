package unsw.sso.pages;

public abstract class Page {
    public abstract Page interact(Object o);
    public abstract String getPageName();
}
