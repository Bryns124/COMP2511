package unsw.sso.pages;

import unsw.sso.providers.Provider;

public class SelectProviderPage extends Page {
    @Override
    public Page interact(Object o) {
        if (o instanceof Provider && o.getClass()) {
            return 
        }
    }

    @Override
    public String getPageName() {
        return "Select a Provider";
    }
}
