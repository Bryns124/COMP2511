package unsw.sso.providers;

public abstract class Provider {

}
